//============================================================================
// Name        : grade.cpp
// Author      : 
// Version     :
// Copyright   : Your copyright notice
// Description : grades in C++, Ansi-style
//============================================================================

#include <iostream>
#include<cstdlib>
#include<ctime>
using namespace std;

struct student
{
	int name;
	int grade;
};
student class1[10];
student class2[10];
student class3[10];
student class4[10];
student class5[10];
int main()
{
	srand((unsigned)time(NULL));
	for(int i=0;i<10;i++)
	{
		class1[i].name=i+1;
		class1[i].grade=rand()%100;
		class2[i].name=i+1;
		class2[i].grade=rand()%100;
		class3[i].name=i+1;
		class3[i].grade=rand()%100;
		class4[i].name=i+1;
		class4[i].grade=rand()%100;
		class5[i].name=i+1;
		class5[i].grade=rand()%100;
	}
	for(int i=0;i<10;i++)
	{
		cout<<"class_1"<<"  "<<class1[i].name<<":  "<<class1[i].grade<<endl;
	}
	for(int i=0;i<10;i++)
	{
		cout<<"class_2"<<"  "<<class2[i].name<<":  "<<class2[i].grade<<endl;
	}
	for(int i=0;i<10;i++)
	{
		cout<<"class_3"<<"  "<<class3[i].name<<":  "<<class3[i].grade<<endl;
	}
	for(int i=0;i<10;i++)
	{
		cout<<"class_4"<<"  "<<class4[i].name<<":  "<<class4[i].grade<<endl;
	}
	for(int i=0;i<10;i++)
	{
		cout<<"class_5"<<"  "<<class5[i].name<<":  "<<class5[i].grade<<endl;
	}
	return 0;
}