//============================================================================
// Name        : huiwenshu.cpp
// Author      : 
// Version     :
// Copyright   : Your copyright notice
// Description : huiwenshu in C++, Ansi-style
//============================================================================

#include <iostream>
#include<string>
#include<algorithm>
using namespace std;

void palindrome(string str)
{
	string str_0;
	str_0=str;
	reverse(str.begin(),str.end());
	if(str==str_0)
		cout<<"It is palindrome."<<endl;
	else
		cout<<"It is not palindrome."<<endl;
}
int main()
{
	string str;
	cout<<"Enter a string: "<<endl;
	cin>>str;
	palindrome(str);
	return 0;
}