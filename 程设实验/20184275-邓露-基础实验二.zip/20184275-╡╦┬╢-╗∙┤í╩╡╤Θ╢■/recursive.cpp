//============================================================================
// Name        :digui.cpp
// Author      : 
// Version     :
// Copyright   : Your copyright notice
// Description : diguiin C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;

void recursive(int num)
{
	if(num!=0)
		if(num > 0 && num <= 9)
			cout << num;
		else
			cout << num % 10;
		    num = num / 10;
		    recursive(num);
}
int main()
{
	int num;
	cout << "enter a number: " << endl;
	cin >> num;
	while (num < 1000)
	{
		cout << "wrong number" << endl;
		cout << "enter another number" << endl;
		cin >> num;
	}
	recursive(num);
    return 0;
}