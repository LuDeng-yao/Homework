#include<string>
#include<iostream>
#include<fstream>
#include<vector>
#include <sstream>
#include <stdlib.h>
using namespace std;


class dep_card
{
public:
	dep_card(string c[6]);
	string num;
	string name;
	string idnum;
	string pw;
	int money;
	int today_total_withdraw;
};

class bor_card
{
public:
	bor_card(string c[7]);
	string num;
	string name;
	string idnum;
	string pw;
	int credit;
	int debt;
	int today_total_withdraw;
};

dep_card::dep_card(string c[6])
{
	num=c[0];
	name=c[1];
	idnum=c[2];
	pw=c[3];
	money=atoi(c[4].c_str());
	today_total_withdraw=atoi(c[5].c_str());
}

bor_card::bor_card(string c[7])
{
	num=c[0];
	name=c[1];
	idnum=c[2];
	pw=c[3];
	credit=atoi(c[4].c_str());
	debt=atoi(c[5].c_str());
	today_total_withdraw=atoi(c[6].c_str());
}


class atm
{
public:
    atm();
	bool welcome();

private:

    static const char *dep_file_path;
    static const char *bor_file_path;
	bool read_fdep();
	bool read_fbor();

    int update_local_dep();
	int update_local_bor();

	bool reg_suc();
	bool exist(string cn,string cp,int insert_type);
	void show_menu();
    void do_command();

    void show_money();
	void show_debt_credit();

	int validate_input_amount(int amount, bool hundredFlag);
	int validate_limit_amount(int amount);

	int withdraw_cash();

	int validate_account(int transferType,string account_1, string account_2);
	int transfer(int &transferType);

	int validate_password(int password,int password2);
	int change_password();

	vector<dep_card> dep_cards;
	vector<bor_card> bor_cards;
	int insert_type;
	int log_index;

	static const int singleWithdrawLimit;
	static const int todayWithdrawLimit;
};




const char* atm::dep_file_path="card.txt";
const char* atm::bor_file_path="card2.txt";
const int atm::singleWithdrawLimit = 2000;
const int atm::todayWithdrawLimit = 8000;

atm::atm()
{
    if(!(read_fdep() && read_fbor()))
	{
        exit(-1);
    }
}

bool atm::read_fdep()
{
	ifstream f1(dep_file_path);
	string info_temp[6];
	int i=0;
	if(!f1.is_open())
	{
        cout<<"Fail to open the deposit file!"<<endl;
        return false;
	}
	while(!f1.eof())
	{
		f1>>info_temp[i];
		i++;
		if(i==5)
		{
		    info_temp[5] = '0';   //the amount of fetched money today
			dep_card card_temp(info_temp);
			dep_cards.push_back(card_temp);
			i=0;
		}
	}
	f1.close();
	return true;
}

bool atm::read_fbor()
{
	ifstream f2(bor_file_path);
	string info_temp[7];
	int i=0;
	if(!f2.is_open())
	{
        cout<<"Fail to open the debt file!"<<endl;
        return false;
	}
	while(!f2.eof())
	{
		f2>>info_temp[i];
		i++;
		if(i==6)
		{
		    info_temp[6] = '0';    //the amount of fetched money today
			bor_card card_temp(info_temp);
			bor_cards.push_back(card_temp);
			i=0;
		}
	}
	f2.close();
	return true;
}

int atm::update_local_dep()
{
    ofstream os1;
	os1.open(dep_file_path);
	if (!os1.is_open()) return -1;

	for (int i = 0; i < dep_cards.size(); i++)
	{
		os1 << dep_cards[i].num << endl
            << dep_cards[i].name << endl
            << dep_cards[i].idnum << endl
            << dep_cards[i].pw << endl
            << dep_cards[i].money << endl;
	}
	os1.close();
	return 0;
}

int atm::update_local_bor()
{
    ofstream os2;
	os2.open(bor_file_path);
	if (!os2.is_open()) return -1;

	for (int i = 0; i < bor_cards.size(); i++)
	{
		os2 << bor_cards[i].num << endl
            << bor_cards[i].name << endl
            << bor_cards[i].idnum << endl
            << bor_cards[i].pw << endl
            << bor_cards[i].credit << endl
            << bor_cards[i].debt << endl;
	}
	os2.close();
	return 0;
}


bool atm::welcome()
{
	cout<<"Welcome!"<<endl;
	if(!reg_suc())
		return false;
    cout<<"Logining successed!"<<endl;

    if(insert_type == 1)
	{
        cout<<dep_cards[log_index].name;
        cout<<",function for the deposit users!"<<endl;
    }
	else
	{
        cout<<bor_cards[log_index].name;
        cout<<", function for debt users"<<endl;
    }

    show_menu();
    do_command();

    return true;
}

bool atm::reg_suc()
{
	string cn,cp;
	int i=0;

	do
	{
        cout<<"Please input your account type: "<<endl;
		cout<<"1 for deposit users, and 2 for debt users."<<endl;
        cin>>insert_type;
        if(insert_type != 1 && insert_type != 2)
		{
            cout<<"Input wrong! Please input a valid number!"<<endl;
        }
	}
	while(insert_type !=1 && insert_type != 2);

	while(i<3)
	{
		cout<<"Input your bank acount: "<<endl;
		cin>>cn;
		cout<<"Input you password: "<<endl;
		cin>>cp;
		if(exist(cn,cp,insert_type))
		{
			return true;
		}
		i++;
		cout<<"The account number or the password you input is wrong."<<endl;

	}
	cout<<"You have failed three times and your card is locked!"<<endl;
	return false;

}


bool atm::exist(string cn,string cp,int insert_type)
{
	if(insert_type==1)
	{
		for(int i=0;i<dep_cards.size();i++)
		{
			if(cn.compare(dep_cards[i].num)==0&&cp.compare(dep_cards[i].pw)==0)
			{
			    log_index = i;
				return true;
			}
		}
	}
	else
	{
	    for(int i=0;i<bor_cards.size();i++)
		{
			if(cn.compare(bor_cards[i].num)==0&&cp.compare(bor_cards[i].pw)==0)
			{
			    log_index = i;
				return true;
			}
		}
	}
	return false;
}


void atm::show_menu()
{
    if(insert_type == 1)
    {
		cout << "\t1 - show the bank saving"<<endl;
		cout << "\t2 - fetch money"<<endl;
		cout << "\t3 - transfer money"<<endl;
		cout << "\t4 - modify password"<<endl;
		cout << "\t5 - exit"<<endl;
	}
	else
    {
		cout << "\t1 - show the debt and the credit"<<endl;
		cout << "\t2 - fetch money"<<endl;
		cout << "\t3 - modify money"<<endl;
		cout << "\t4 - exit"<<endl;
    }
}

void atm::do_command()
{
	int command;
	cout << "Input the corrspond number to choose the survice you want to get: ";
	while (cin >> command)
	{
		if (insert_type == 1)
		{
			switch (command)
			{
			case 1:
				show_money();
				break;
			case 2:
				if (withdraw_cash() == 0)
				{
					if (update_local_dep() != 0)
					{
						cout << "Fail to update the file of deposit account."<<endl;
					}
				}
				break;
			case 3:
				int transferType;
				if (transfer(transferType) == 0)
				{
					//success
					if (update_local_dep() != 0)
					{
						cout << "Fail to update the file of deposit account."<<endl;
					}
					if (transferType == 2)
					{
						if (update_local_bor() != 0)
						{
                            cout << "Fail to update the file of debt account."<<endl;
                        }
					}
				}
				break;
			case 4:
				change_password();
				if (update_local_dep() != 0)
				{
					cout << "Fail to update the file of deposit account."<<endl;
				}
				break;
			case 5:
				exit(0);
			default:
				cout << "Input wrong!"<<endl;
			}
		}
		else
		{
			switch (command)
			{
			case 1:
				show_debt_credit();
				break;
			case 2:
				if (withdraw_cash() == 0)
				{
					//success
					if (update_local_bor() != 0)
					{
						cout << "Fail to update the file of debt account."<<endl;
					}
				}
				break;
			case 3:
				change_password();
				if (update_local_bor() != 0)
				{
					cout << "Fail to update the file of debt account."<<endl;
				}
				break;
			case 4:
				exit(0);
			default:
				cout << "Input wrong!"<<endl;
			}
		}
		cout << "Input the corrspond number to choose the survice yu want to get: ";

	}
}


void atm::show_money()
{
    cout << dep_cards[log_index].money<<endl;
}

void atm::show_debt_credit()
{
    cout << "the amount of debt: "
        << bor_cards[log_index].debt << endl
        << "the amount of credit: "
        << bor_cards[log_index].credit<<endl;
}

int atm::validate_input_amount(int amount, bool hundredFlag)
{
	if (amount == 0) return 0;
	if (amount < 0)
	{
		cout << "Input wrong! The amount must be positive!"<<endl;
		return -1;
	}
	if (hundredFlag && amount % 100 != 0)
	{
		cout << "Input wrong! The amount must be a multiple of hundred."<<endl;
		return -1;
	}

	return 1;
}

int atm::validate_limit_amount(int amount)
{
    if (amount > atm::singleWithdrawLimit)
	{
		cout << "Withdraw money failed! It has beyond the limit of a single time!"<< singleWithdrawLimit << "RMB"<<endl;
		return -1;
	}

	if (insert_type == 1)
	{
		if (dep_cards[log_index].today_total_withdraw > todayWithdrawLimit)
		{
			cout << "Withdraw money failed! It has beyond the limit of a single day!" << todayWithdrawLimit << "Ԫ"<<endl;
			return -1;
		}

		if (dep_cards[log_index].money - amount < 0)
		{
			cout << "Withdraw money failed! The left money is not enough."<<endl;
			return -1;
		}

	}
	else
	{
		if (bor_cards[log_index].today_total_withdraw > todayWithdrawLimit)
		{
			cout << "Withdraw money failed! It has beyond the limit of a single day!" << todayWithdrawLimit << "Ԫ"<<endl;
			return -1;
		}

		if (bor_cards[log_index].debt + amount > bor_cards[log_index].credit)
		{
			cout << "Withdraw money failed! Your credit is not enough."<<endl;
			return -1;
		}

	}

	return 0;
}

int atm::withdraw_cash()
{
Withdraw:
	int amount;
	int validate;
	cout << "Please input the amount you want to withdraw: (input 0 to shift to the main menu)"<<endl;

	while (cin >> amount)
	{
		validate = validate_input_amount(amount,true);
		if (validate == 0) return -1;
		if (validate == 1) break;
		cout << "lease input the amount you want to withdraw: (input 0 to shift to the main menu)"<<endl;
	}

	if (insert_type == 1)
	{
		if (validate_limit_amount(amount) != 0)
		{
			goto Withdraw;
		}
		else
		{
			dep_cards[log_index].money -= amount;
			dep_cards[log_index].today_total_withdraw += amount;
		}

	}
	else
	{
		if (validate_limit_amount(amount) != 0)
		{
			goto Withdraw;
		}
		else
		{
			bor_cards[log_index].debt += amount;
			bor_cards[log_index].today_total_withdraw += amount;
		}
	}
	return 0;
}

int atm::validate_account(int transferType, string account_1, string account_2)
{
    if (account_1.compare(account_2) != 0)
	{
		cout << "The two accounts you put these two times are different."<<endl;
		return -1;
	}
	if (transferType == 1)
	{
		for (int i = 0; i < dep_cards.size(); i++)
		{
			if (dep_cards[i].num.compare(account_1) == 0)
			{
				return i;
			}
		}

	}
	else
	{
		for (int i = 0; i < bor_cards.size(); i++)
		{
			if (bor_cards[i].num.compare(account_1) == 0)
			{
				return i;
			}
		}
	}
	cout << "The account is not exist."<<endl;

	return -1;
}

int atm::transfer(int &transferType)
{
    int type_buff = 0;

	while (type_buff == 0)
	{
		cout << "Input the account type please: "<<endl;
		cout << "1 for deposit users. And 2 for debt users.";
		cin >> type_buff;
        if(type_buff == 1 or type_buff == 2)
		{
            transferType = type_buff;
        }
		else
		{
			cout << "Input wrong!"<<endl;
			type_buff = 0;
			continue;
		}
	}

	int pos = -1;

	string account_1, account_2;

	while (pos == -1)
	{

		char caccount_1[19], caccount_2[19];

		cout << "Please input the account number you want to transfer to: (input 0 to shift to the main menu)"<<endl;
		cin >> caccount_1;
		account_1 = caccount_1;
		if (account_1.compare("0") == 0) return -1;

		cout << "Please input the account number again: "<<endl;
		cin >> caccount_2;
		account_2 = caccount_2;
		pos = validate_account(transferType, account_1, account_2);

	}

	if (transferType == 1 && account_1.compare(dep_cards[log_index].num) == 0)
	{
		cout << "Forbid to transferring money to youself!"<<endl;
		return -1;
	}

	int amount;
	cout << "Please input the amount you want to transfer: (input 0 to shift to the main menu)\n";

	int validate;
	while (cin >> amount)
	{
		validate = validate_input_amount(amount,false);
		if (validate == 0) return -1;
		if (validate == 1) break;
	}
    if (dep_cards[log_index].money - amount < 0)
	{
        cout << "Input amount wrong! The left money is not enough."<<endl;
        return -1;
    }
	else
	{
        dep_cards[log_index].money -= amount;
    }

	if (transferType == 1)
	{
		dep_cards[pos].money += amount;
	}
	else
	{
		bor_cards[pos].debt -= amount;

		if (bor_cards[pos].debt < 0)
		{
			cout << "The money is more than the debt, and the beyond part has been sent back."<<endl;
			dep_cards[log_index].money += (0 - bor_cards[pos].debt);
			bor_cards[pos].debt = 0;
		}

	}

	return 0;
}

int atm::validate_password(int password,int password2)
{

	if (to_string(password).length() != 6) return -1;
	if(password!=password2) return -2;
	return 0;
}

int atm::change_password()
{
changePassword:
	int newPass,newPass2;
	cout << "Please input your new password: ";
	cin >> newPass;
	cout << "Please input your new password again: ";
	cin >> newPass2;
	if (validate_password(newPass,newPass2) == -1)
    {
		cout << "Input wrong! The password you input must be a six-digit number."<<endl;
		goto changePassword;
	}
	else
	if(validate_password(newPass,newPass2) == -2)
	{
		cout << "Input wrong! The passwords you input these two times are diferent."<<endl;
		goto changePassword;
	}

	if (insert_type == 1)
	{

		dep_cards[log_index].pw = to_string(newPass);
	}
	else
	{
		bor_cards[log_index].pw = to_string(newPass);
	}
	return 0;

}

int main(int argc, char** argv)
{
	atm a;
	a.welcome();
	return 0;
}
