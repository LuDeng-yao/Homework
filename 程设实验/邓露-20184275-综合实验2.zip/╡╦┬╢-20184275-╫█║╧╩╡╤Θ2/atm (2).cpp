#include<iostream>
#include<string.h>
#include<stdlib.h>
#include <fstream>

using namespace std;

class consumer;
class ATM
{
public:
ATM(consumer& cn):cnsm(cn){}
void welcome();        // login
bool check_password(char n[],char pwd[]);         // check password
void change_password();        // change password
void fetchmoney();       // fetch money
void transfermoney1();         // transfer money for deposit user
void transfermoney2();         // transfer money for debt user
void information1();   // get information for deposit
void information2();    //get information for credit
void exit();     // exit ATM
void functionshow1();       // function for deposit consumer
void functionshow2();       //function for credit consumer
void lock();   //lock
private:
int times;  // wrong times
consumer& cnsm;
};

class deposit_consumer
{
public:
friend class ATM;
deposit_consumer(char Name[],char Num[],char ID[],float Money,char PassWord[]);
protected:
char* get_name();      //get user name
char* get_num();       //get account number
char* get_id();        //get ID number
char* get_password();       // get password
float get_money();       //get money
void set_password(char pwd[]);   // set password
void set_money(float m);     //fetch money
void transfer_money1(float p);      //transfer money for deposit consumer
private:
char password[6];
char name[20];
char num[19];
char id[18];
float money;
};

class debt_consumer
{
public:
friend class ATM;
debt_consumer(char Name[],char Num[],char ID[],float Credit[],float Debt[],char PassWord[]);
protected:
char* get_name();      //get user name
char* get_num();       //get account number
char* get_id();        //get ID number
char* get_password();       // get password
float get_credit();      //get credit
float get_debt();       //get debt
void set_password(char pwd[]);   // set password
void borrow_money(float n);     //fetch money
void transfer_money2(float q);      //transfer money for debt consumer
private:
char password[6];
char name[20];
char num[19];
char id[18];
float debt;
float credit;
};

deposit_consumer::deposit_consumer(char Name[],char Num[],char ID[],float Money,char PassWord[])
{
    strcpy(name,Name);
    strcpy(num,Num);
    money=Money;
    strcpy(password,PassWord);
}
float deposit_consumer::get_money()
{
return money;
}
char* deposit_consumer::get_name()
{
return name;
}
char* deposit_consumer::get_num()
{
return num;
}
char*deposit_consumer::get_id()
{
    return id;
}
char* deposit_consumer::get_password()
{
return password;
}
void deposit_consumer::set_money(float m)
{
money-=m;
}
void deposit_consumer::set_password(char pwd[])
{
strcpy(password,pwd);
}

debt_consumer::debt_consumer(char Name[],char Num[],char ID[],float Credit,float Debt,char PassWord[])
{
    strcpy(name,Name);
    strcpy(num,Num);
    credit=Credit;
    debt=Debt;
    strcpy(password,PassWord);
}
float debt_consumer::get_credit()
{
return credit;
}
float debt_comsumer::get_debt()
{
    return debt;
}
char* debt_consumer::get_name()
{
return name;
}
char* debt_consumer::get_num()
{
return num;
}
char*debt_consumer::get_id()
{
    return id;
}
char* debt_consumer::get_password()
{
return password;
}
void debt_consumer::borrow_money(float n)
{
debt+=n;
credit-=n;
}
void debt_consumer::set_password(char pwd[])
{
strcpy(password,pwd);
}

void ATM::welcome()
{
    times=0;
    cout<<"**********welcome**********"<<endl;
    cout<<"           login           "<<endl;
    char pwd[6],num[19],id[18],ch;
    int i=0;
    do
    {
        i=0;
        cout<<"Input your accout number:"<<endl;
        do
        {
            cin.get(ch);
            num[i++]=ch;
        }
        while(ch!=' ');
        num[i-1]=' ';
        i=0;
        cout<<"Input your ID number:"<<endl;
        do
        {
            cin.get(ch);
            id[i++]=ch;
        }
        while(ch!=' ');
        id[i-1]=' ';
        i=0;
        cout<<"Input your password:"<<endl;
        do
        {
            cin.get(ch);
            pwd[i++]=ch;
        }
        while(ch!=' ');
        pwd[i-1]=' ';
        if(!check_password(num,pwd))
        {
            cout<<"The account number (or ID number) or the password you input is wrong. please input it again."<<endl;
            times++;
        }
        else
        {
            functionshow1();
            if(!fin)
            {
                functionshow2()
            }
        }
    }
    while(times>3);
    lock();
}
bool ATM::check_password(char num[],
char pwd[])
{
if(strcmp(num,cnsm.get_num())==0&&strcmp
(pwd,cnsm.get_password())==0)
return true;
else
return false;
}
void ATM::functionshow1()
{
    int n;
    do
    {
        cout<<"Choose the corresponding number to do: "<<endl;
        cout<<"1) modify the password "<<endl;
        cout<<"2) fetch money　　 "<<endl;
        cout<<"3) transfer money  "<<endl;
        cout<<"4) get information  "<<endl;
        cout<<"5) exit "<<endl;
        cout<<"$ >/";
        cin>>n;
        while(n<1||n>5)
        {
            cout<<"Please input the right number!"<<endl;
            cout<<"$ >/";
            cin>>n;
        }
        switch(n)
        {
            case '1': 
            change_password();
            break;
            case '2': 
            fetchmoney();
            break;
            case '3': 
            information();
            break;
            case '4':
            transfermoney();
            break;
            case '5':
            exit();
            break;
        }
    }
}

void ATM::functionshow2()
{
    int n;
    do
    {
        cout<<"Choose the corresponding number to do: "<<endl;
        cout<<"1) modify the password "<<endl;
        cout<<"2) borrow money　　 "<<endl;
        cout<<"3) transfer money  "<<endl;
        cout<<"4) get information  "<<endl;
        cout<<"5) exit "<<endl;
        cout<<"$ >/";
        cin>>n;
        while(n<1||n>5)
        {
            cout<<"Please input the right number!"<<endl;
            cout<<"$ >/";
            cin>>n;
        }
        switch(n)
        {
            case '1': 
            change_password();
            break;
            case '2': 
            borrowmoney();
            break;
            case '3': 
            information();
            break;
            case '4':
            transfermoney();
            break;
            case '5':
            exit();
            break;
        }
    }
}
while(true);
{
    void ATM::change_password()
    {
        char pwd[6],repwd[6];
        times=0;
        do
        {
            cout<<"Input the old password please："<<endl;
            cin>>pwd;
            if(!check_password(cnsm.get_num(),pwd))
            times++;
            else
            break;
        }
    }
    while(times<3);
    if(times==3)
    lock();
    int t=0;
    do
    {
        cout<<"Set the new password：";
        cin>>pwd;
        cout<<"Input your new password again：";
        cin>>repwd;
        if((t=strcmp(pwd,repwd))!=0)
        cout<<"The passwords you input these two times are different. Please reinput it!"<<endl;
    }
    while(t!=0);
    cnsm.set_password(pwd);
    cout<<"Password modifying successed!"<<endl;
}
void ATM::fetchmoney()
{
    float m;
    char ch;
    do
    {
        cout<<endl<<"How much money do you want to get:" <<" $>/"<<endl;
        cin>>m;
        while(m<=0)
        {
            cout<<"Please input a proper number!"<<endl;
            cout<<"$ >/ ";
            cin>>m;
        }
        if(cnsm.get_money()-m<0)
        {
            cout<<"Sorry, you deposit is not enough."<<endl;
        }
        else
        {
            cout<<endl<<"Fetchig successed! Keep the money please."<<endl;
            cnsm.set_money(m);
        }
        cout<<"Still go on：(Y/N) "<<endl;
        cout<<"$ >/ ";
        cin>>ch;
        while(ch!='n'&&ch!='N'&&ch!='Y'&&ch!='y')
        {
            cout<<"$ >/";
            cin>>ch;
        }
    }
    while(ch=='y'||ch=='Y');
}

void ATM::borrowmoney()
{
    float m;
    char ch;
    do
    {
        cout<<endl<<"How much money do you want to get:" <<" $>/"<<endl;
        cin>>m;
        while(m<=0)
        {
            cout<<"Please input a proper number!"<<endl;
            cout<<"$ >/ ";
            cin>>m;
        }
        if(cnsm.get_credit()-m<0)
        {
            cout<<"Sorry, you credit is not enough."<<endl;
        }
        else
        {
            cout<<endl<<"Borrowing successed! Keep the money please."<<endl;
            cnsm.set_money(m);
        }
        cout<<"Still go on：(Y/N) "<<endl;
        cout<<"$ >/ ";
        cin>>ch;
        while(ch!='n'&&ch!='N'&&ch!='Y'&&ch!='y')
        {
            cout<<"$ >/";
            cin>>ch;
        }
    }
    while(ch=='y'||ch=='Y');
}
void ATM::transfermoney1()
{
    float m;
    char ch;
    do
    {
        cout<<endl<<"How much money do you want to transfer:" <<" $>/"<<endl;
        cin>>m;
        while(m<=0)
        {
            cout<<"Please input a proper number!"<<endl;
            cout<<"$ >/ ";
            cin>>m;
        }
        if(cnsm.get_money()-m<0)
        {
            cout<<"Sorry, your deposit is not enough."<<endl;
        }
        else
        {
            while(m%100!=0)
            {
                cout<<"Please input a proper number!"<<"$ >/ ";
                cin>>m;
            }
            else
            {
                cout<<"Input the account number you will transfer your deposit to: "
                cin>>num[];
                cout<<"Transferingig successed! "<<endl;
                cnsm.set_money(m);
            }
        }
        cout<<"Still go on：(Y/N) ";
        cout<<"$ >/ ";
        cin>>ch;
    }
    while(ch!='n'&&ch!='N'&&ch!='Y'&&ch!='y')
    {
        cout<<"$ >/";
        cin>>ch;
    }
    while(ch=='y'||ch=='Y');
}

void ATM::transfermoney2()
{
    float m;
    char ch;
    do
    {
        cout<<endl<<"How much money do you want to transfer:" <<" $>/"<<endl;
        cin>>m;
        while(m<=0)
        {
            cout<<"Please input a proper number!"<<endl;
            cout<<"$ >/ ";
            cin>>m;
        }
        if(cnsm.get_money()-m<0)
        {
            cout<<"Sorry, your credit is not enough."<<endl;
        }
        else
        {
            while(m%100!=0)
            {
                cout<<"Please input a proper number!"<<"$ >/ ";
                cin>>m;
            }
            else
            {
                cout<<"Input the account number you will transfer your money to: "
                cin>>num[];
                cout<<"Transferingig successed! "<<endl;
                cnsm.set_money(m);
            }
        }
        cout<<"Still go on：(Y/N) ";
        cout<<"$ >/ ";
        cin>>ch;
    }
    while(ch!='n'&&ch!='N'&&ch!='Y'&&ch!='y')
    {
        cout<<"$ >/";
        cin>>ch;
    }
    while(ch=='y'||ch=='Y');
}

void ATM::information1()
{
cout<<"**********************************"<<endl;
cout<<"*"<<endl;
cout<<"*　　 User："<<cnsm.get_name()<<endl;
cout<<"* account number："<<cnsm.get_num()<<endl;
cout<<"*　　 money:　　 "<<cnsm.get_money()<<endl;
cout<<"**********************************"<<endl;
}
void ATM::information2()
{
cout<<"**********************************"<<endl;
cout<<"*"<<endl;
cout<<"*　　 User："<<cnsm.get_name()<<endl;
cout<<"* account number："<<cnsm.get_num()<<endl;
cout<<"*　　 credit:　　 "<<cnsm.get_credit()<<endl;
cout<<"*　　 debt:　　 "<<cnsm.get_credit()<<endl;
cout<<"**********************************"<<endl;
}
void ATM::lock()
{
cout<<endl<<"Sorry, because of your mistake, your card has been confiscated! "<<endl;
return exit();
}
void ATM::exit()
{
cout<<endl<<"Thanks for your supporting to our bank. Welcome to you next time!"<<endl;
cout<<"Please keep your card!"<<endl;
return exit();
}

//使用get()一次读一个字符

void main()
{
ifstream fin("ATMuser1.txt");
if (!fin) 
{
    cout << "File open error!\n";
    return;
}
char c;
while ((c=fin.get()) != EOF) cout << c;    //注意结束条件的判断
fin.close();
ifstream fin("ATMuser2.txt");
if (!fin) 
{
    cout << "File open error!\n";
    return;
}
char c;
while ((c=fin.get()) != EOF) cout << c;    //注意结束条件的判断
fin.close();
}