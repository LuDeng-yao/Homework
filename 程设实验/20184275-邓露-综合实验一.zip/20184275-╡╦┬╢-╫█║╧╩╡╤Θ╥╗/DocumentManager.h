#ifndef CIRCLE_H
#define CIRCLE_H

#include<iostream>
#include<sstream>
#include <fstream>
#include<stdlib.h>
#include <stdio.h>
#include <errno.h>
#include <string.h>
#include <dirent.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <dirent.h>
#include<ctime>
using namespace std;

class DocumentManager
{
private:
    char *path;
    char *newpath;
public:
    DocumentManager();
    DocumentManager( char *path);

    void setNewpath( char* newpath);
    void setPath( char* path);
    void displayTips();

    int make_dir(const char *path, mode_t mode);
    int change_dir(const char *path);
    int remove_dir(const char* path);
    int get_file_size_time(const char *filename);
    DIR * open_dir(const char *path);
    void read_dir(const char *path, bool ListAllFiles);
    int copy_dir(const char *filename, const char *newfilename);

};

#endif
